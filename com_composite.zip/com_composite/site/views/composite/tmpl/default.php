<?php
defined('_JEXEC') or die;
mb_internal_encoding( 'UTF-8' );

echo '<article class="composite" xmlns="http://www.w3.org/1999/xhtml" >';
echo $this->composition;
echo '</article>';
