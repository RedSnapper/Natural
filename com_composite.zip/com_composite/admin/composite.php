<?php
defined('_JEXEC') or die;

echo "Nothing to configure here!";

